package learn.spring.web.configuration;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Created by artem_shevtsov on 1/13/17.
 */
public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}
