package learn.spring.exception;

/**
 * Created by aftor on 07.01.17.
 */
public class UnprocessableFileFormatExcepption extends Exception {
    public UnprocessableFileFormatExcepption(String message) {
        super(message);
    }
}
